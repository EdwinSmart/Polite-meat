const logoutBtn = document.querySelector(".logout-btn")

logoutBtn.addEventListener("click", () => {
  window.location.replace("admin.html")
})